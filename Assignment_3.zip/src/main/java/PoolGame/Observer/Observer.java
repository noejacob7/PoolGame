package PoolGame.Observer;

import PoolGame.Items.Ball;

public interface Observer {
    public void update();
}
